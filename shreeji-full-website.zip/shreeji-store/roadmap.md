# Store update
- [x] Resume the preview and verify the public store with minimal work; avoid new imagery and extra features.
- [ ] Remove before–after and refresh girls’ accessories storefront with glass styling and model cover.
- [ ] Add category browsing, product details and cart with guest order submission.
- [ ] Add Cloud product storage, image upload, Google admin login, profile and protected product management.
- [ ] Add dashboard orders, customers, sales, fulfilment tracking and account information.
- [ ] Verify storefront, cart and admin flow; admin role assignment requires the owner’s signed-in account.