CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TABLE public.user_roles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL, role public.app_role NOT NULL, UNIQUE(user_id,role));
GRANT SELECT ON public.user_roles TO authenticated; GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role=_role) $$;
CREATE POLICY role_read ON public.user_roles FOR SELECT TO authenticated USING (user_id=auth.uid());
CREATE TABLE public.profiles (id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE, display_name text NOT NULL DEFAULT '', email text NOT NULL DEFAULT '', avatar_url text NOT NULL DEFAULT '');
GRANT SELECT, UPDATE ON public.profiles TO authenticated; GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY profile_read ON public.profiles FOR SELECT TO authenticated USING(id=auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY profile_update ON public.profiles FOR UPDATE TO authenticated USING(id=auth.uid()) WITH CHECK(id=auth.uid());
CREATE FUNCTION public.create_profile() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$ BEGIN INSERT INTO public.profiles(id,email,display_name,avatar_url) VALUES(NEW.id,coalesce(NEW.email,''),coalesce(NEW.raw_user_meta_data->>'full_name',''),coalesce(NEW.raw_user_meta_data->>'avatar_url','')); RETURN NEW; END; $$;
CREATE TRIGGER on_accessories_signup AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.create_profile();
CREATE TABLE public.products (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text UNIQUE NOT NULL, name text NOT NULL, note text NOT NULL DEFAULT '', category text NOT NULL, price numeric(10,2) NOT NULL CHECK(price>=0), image_path text NOT NULL, stock integer NOT NULL DEFAULT 1 CHECK(stock>=0), active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT ON public.products TO anon; GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated; GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY catalog_read ON public.products FOR SELECT TO anon, authenticated USING(active);
CREATE POLICY product_admin ON public.products FOR ALL TO authenticated USING(public.has_role(auth.uid(),'admin')) WITH CHECK(public.has_role(auth.uid(),'admin'));
INSERT INTO public.products(id,slug,name,note,category,price,image_path,stock) VALUES
('11111111-1111-4111-8111-111111111111','gulabi-jhumkas','Gulabi Jhumkas','A playful pop of pink, tiny pearls, and a whole lot of personality.','Jhumkas',349,'sample:jhumkas',20),
('22222222-2222-4222-8222-222222222222','cherry-satin-bow','Cherry Satin Bow','The sweetest finishing touch for a ponytail or half-up moment.','Hair Accessories',199,'sample:bow',20),
('33333333-3333-4333-8333-333333333333','flower-pop-bracelets','Flower Pop Bracelets','Three beaded bracelets with little flower charms. Stack them your way.','Bracelets',249,'sample:bracelets',20),
('44444444-4444-4444-8444-444444444444','sweetheart-pearl-necklace','Sweetheart Pearl Necklace','Imitation pearls meet a cherry-red heart. A little everyday romance.','Necklaces',299,'sample:necklace',20);
CREATE TABLE public.orders (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), reference text UNIQUE NOT NULL DEFAULT ('LN-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))), customer_name text NOT NULL, email text NOT NULL DEFAULT '', phone text NOT NULL, address text NOT NULL, total numeric(12,2) NOT NULL, status text NOT NULL DEFAULT 'New' CHECK(status IN ('New','Confirmed','Shipped','Delivered','Cancelled')), payment_status text NOT NULL DEFAULT 'Unpaid' CHECK(payment_status IN ('Unpaid','Paid','Refunded')), tracking_number text NOT NULL DEFAULT '', admin_note text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, UPDATE ON public.orders TO authenticated; GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY order_admin ON public.orders FOR ALL TO authenticated USING(public.has_role(auth.uid(),'admin')) WITH CHECK(public.has_role(auth.uid(),'admin'));
CREATE TABLE public.order_items (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE, product_id uuid, name text NOT NULL, price numeric(10,2) NOT NULL, quantity integer NOT NULL CHECK(quantity>0));
GRANT SELECT ON public.order_items TO authenticated; GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY item_admin ON public.order_items FOR SELECT TO authenticated USING(public.has_role(auth.uid(),'admin'));
CREATE POLICY image_catalog_read ON storage.objects FOR SELECT TO anon,authenticated USING(bucket_id='product-images');
CREATE POLICY image_admin_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK(bucket_id='product-images' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY image_admin_update ON storage.objects FOR UPDATE TO authenticated USING(bucket_id='product-images' AND public.has_role(auth.uid(),'admin')) WITH CHECK(bucket_id='product-images' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY image_admin_delete ON storage.objects FOR DELETE TO authenticated USING(bucket_id='product-images' AND public.has_role(auth.uid(),'admin'));
CREATE FUNCTION public.place_accessories_order(_name text,_email text,_phone text,_address text,_items jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE v_product public.products; v_item jsonb; v_total numeric:=0; v_order public.orders; v_qty integer; BEGIN
IF jsonb_array_length(_items)<1 OR jsonb_array_length(_items)>50 OR length(_name)<1 OR length(_name)>100 OR length(_address)<5 OR length(_address)>1000 OR length(_phone)<7 OR length(_phone)>20 OR length(_email)>255 THEN RAISE EXCEPTION 'Invalid order'; END IF;
PERFORM pg_advisory_xact_lock(hashtext(_phone));
IF (SELECT count(*) FROM public.orders WHERE phone=_phone AND created_at>now()-interval '1 hour')>=5 THEN RAISE EXCEPTION 'Too many orders. Please try again later.'; END IF;
FOR v_item IN SELECT value FROM jsonb_array_elements(_items) ORDER BY value->>'id' LOOP
v_qty:=(v_item->>'quantity')::integer;
IF v_qty<1 OR v_qty>99 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
SELECT * INTO v_product FROM public.products WHERE id=(v_item->>'id')::uuid AND active FOR UPDATE;
IF NOT FOUND OR v_product.stock<v_qty THEN RAISE EXCEPTION 'A product is no longer available in this quantity'; END IF;
v_total:=v_total+v_product.price*v_qty;
END LOOP;
INSERT INTO public.orders(customer_name,email,phone,address,total) VALUES(_name,_email,_phone,_address,v_total) RETURNING * INTO v_order;
FOR v_item IN SELECT value FROM jsonb_array_elements(_items) LOOP
v_qty:=(v_item->>'quantity')::integer;
SELECT * INTO v_product FROM public.products WHERE id=(v_item->>'id')::uuid;
UPDATE public.products SET stock=stock-v_qty WHERE id=v_product.id;
INSERT INTO public.order_items(order_id,product_id,name,price,quantity) VALUES(v_order.id,v_product.id,v_product.name,v_product.price,v_qty);
END LOOP;
RETURN jsonb_build_object('reference',v_order.reference,'total',v_total);
END; $$;
REVOKE ALL ON FUNCTION public.place_accessories_order(text,text,text,text,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.place_accessories_order(text,text,text,text,jsonb) TO service_role;