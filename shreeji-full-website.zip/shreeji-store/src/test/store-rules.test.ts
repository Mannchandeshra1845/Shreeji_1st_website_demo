import {describe,it,expect} from 'vitest';
import {cartTotal,orderSchema,productSchema} from '@/lib/store-schema';
describe('store rules',()=>{
 it('calculates cart quantity totals',()=>{expect(cartTotal([{price:349,quantity:2},{price:199,quantity:1}])).toBe(897);});
 it('allows guest orders without email or login',()=>{expect(orderSchema.safeParse({name:'Guest',email:'',phone:'9876543210',address:'12 Main Street',items:[{id:'11111111-1111-4111-8111-111111111111',quantity:1}]}).success).toBe(true);});
 it('requires product name price and photo for admin products',()=>{expect(productSchema.safeParse({name:'',note:'',category:'Jhumkas',price:-1,image_path:'',stock:1,active:true}).success).toBe(false);expect(productSchema.safeParse({name:'Fancy jhumkas',note:'Optional note',category:'Jhumkas',price:349,image_path:'products/photo.jpg',stock:1,active:true}).success).toBe(true);});
});
