import {createContext,useContext,useEffect,useState,type ReactNode} from 'react';
import type {User} from '@supabase/supabase-js';
import {supabase} from '@/integrations/supabase/client';
import {useRouter} from '@tanstack/react-router';
import {useQueryClient} from '@tanstack/react-query';
const IdentityContext=createContext<{user:User|null}>({user:null});
export function IdentityProvider({children}:{children:ReactNode}){const [user,setUser]=useState<User|null>(null);const router=useRouter();const qc=useQueryClient();useEffect(()=>{supabase.auth.getUser().then(({data})=>setUser(data.user));const {data:{subscription}}=supabase.auth.onAuthStateChange((event,session)=>{if(event==='INITIAL_SESSION'){setUser(session?.user??null);return;}if(!['SIGNED_IN','SIGNED_OUT','USER_UPDATED'].includes(event))return;setUser(session?.user??null);void router.invalidate();if(event!=='SIGNED_OUT')void qc.invalidateQueries();});return()=>subscription.unsubscribe();},[router,qc]);return <IdentityContext.Provider value={{user}}>{children}</IdentityContext.Provider>;}
export const useIdentity=()=>useContext(IdentityContext);
