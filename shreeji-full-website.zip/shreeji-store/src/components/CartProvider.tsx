import {createContext,useContext,useState,useEffect,type ReactNode} from 'react';
import type {Product} from '@/lib/products';
import {toast} from 'sonner';
export type CartItem={product:Product;quantity:number};
type CartContextValue={items:CartItem[];add:(p:Product)=>void;change:(id:string,quantity:number)=>void;clear:()=>void;count:number};
const CartContext=createContext<CartContextValue|null>(null);
export function CartProvider({children}:{children:ReactNode}){
 const [items,setItems]=useState<CartItem[]>([]); const [ready,setReady]=useState(false);
 useEffect(()=>{try{const saved=JSON.parse(sessionStorage.getItem('lunara-cart')??'[]');if(Array.isArray(saved))setItems(saved.filter(x=>x?.product?.id&&Number.isInteger(x.quantity)&&x.quantity>0));}catch{}setReady(true);},[]);
 useEffect(()=>{if(ready)sessionStorage.setItem('lunara-cart',JSON.stringify(items));},[items,ready]);
 const add=(p:Product)=>{if(p.stock<1)return;setItems(old=>{const found=old.find(x=>x.product.id===p.id);return found?old.map(x=>x.product.id===p.id?{...x,quantity:Math.min(p.stock,x.quantity+1)}:x):[...old,{product:p,quantity:1}];});toast.success('Added to your bag');};
 return <CartContext.Provider value={{items,add,change:(id,quantity)=>setItems(old=>quantity<=0?old.filter(x=>x.product.id!==id):old.map(x=>x.product.id===id?{...x,quantity:Math.min(x.product.stock,quantity)}:x)),clear:()=>setItems([]),count:items.reduce((n,x)=>n+x.quantity,0)}}>{children}</CartContext.Provider>;
}
export function useCart(){const c=useContext(CartContext);if(!c)throw new Error('Cart unavailable');return c;}
