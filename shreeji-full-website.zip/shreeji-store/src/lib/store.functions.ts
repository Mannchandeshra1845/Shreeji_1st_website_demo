import { createServerFn } from '@tanstack/react-start';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { orderSchema, type OrderInput } from './store-schema';
export const getCatalog = createServerFn({method:'GET'}).handler(async()=>{
 const key=process.env['SUPABASE_PUBLISHABLE_KEY']; const url=process.env['SUPABASE_URL'];
 if(!key||!url) throw new Error('Store unavailable');
 const client=createClient<Database>(url,key,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:(input,init)=>{const h=new Headers(init?.headers); if(key.startsWith('sb_')&&h.get('Authorization')===`Bearer ${key}`)h.delete('Authorization');h.set('apikey',key);return fetch(input,{...init,headers:h});}}});
 const {data,error}=await client.from('products').select('*').eq('active',true).order('created_at',{ascending:false}).limit(1000);
 if(error) throw new Error('Could not load products');
 const paths=(data??[]).filter(p=>!p.image_path.startsWith('sample:')).map(p=>p.image_path);
 const {data:signed}=paths.length?await client.storage.from('product-images').createSignedUrls(paths,3600):{data:[]};
 return (data??[]).map(p=>({...p,price:Number(p.price),image:signed?.find(s=>s.path===p.image_path)?.signedUrl?.replace(url,import.meta.env['VITE_SUPABASE_URL'])??''}));
});
export const placeOrder=createServerFn({method:'POST'}).inputValidator((input:OrderInput)=>orderSchema.parse(input)).handler(async({data})=>{
 const {supabaseAdmin}=await import('@/integrations/supabase/client.server');
 const {data:result,error}=await supabaseAdmin.rpc('place_accessories_order',{_name:data.name,_email:data.email,_phone:data.phone,_address:data.address,_items:data.items});
 if(error) throw new Error('Order could not be placed. Check availability or try again later.');
 return result as {reference:string;total:number};
});
