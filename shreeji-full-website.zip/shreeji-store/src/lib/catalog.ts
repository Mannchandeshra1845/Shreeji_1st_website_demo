import { queryOptions } from '@tanstack/react-query';
import { getCatalog } from './store.functions';
import { sampleImages } from './products';
export const catalogOptions=queryOptions({queryKey:['catalog'],queryFn:async()=> (await getCatalog()).map(p=>({...p,image:sampleImages[p.image_path]??p.image})),staleTime:60_000});
