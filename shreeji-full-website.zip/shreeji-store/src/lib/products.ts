import jhumkas from '@/assets/fancy-jhumkas.jpg';
import bow from '@/assets/satin-bow.jpg';
import bracelets from '@/assets/flower-bracelets.jpg';
import necklace from '@/assets/heart-necklace.jpg';
export const categories = ['Jhumkas','Earrings','Hair Accessories','Necklaces','Bracelets','Bangles','Rings','Anklets','Pendants','Bags & Pouches','Brooches','Accessory Sets','Other Accessories'];
export type Product = { id: string; slug: string; name: string; note: string; category: string; price: number; image_path: string; stock: number; active: boolean; image: string };
export const sampleImages: Record<string,string> = { 'sample:jhumkas': jhumkas, 'sample:bow': bow, 'sample:bracelets': bracelets, 'sample:necklace': necklace };
export const money = (n: number) => '₹' + n.toLocaleString('en-IN');
