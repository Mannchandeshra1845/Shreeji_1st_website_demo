import {queryOptions} from '@tanstack/react-query';
import {getAdminDashboard} from './admin.functions';
export const adminOptions=queryOptions({queryKey:['admin-dashboard'],queryFn:()=>getAdminDashboard(),staleTime:0});
