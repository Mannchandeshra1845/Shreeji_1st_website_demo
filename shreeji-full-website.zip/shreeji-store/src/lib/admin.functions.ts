import {createServerFn} from '@tanstack/react-start';
import {requireSupabaseAuth} from '@/integrations/supabase/auth-middleware';
export const getAdminDashboard=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).handler(async({context})=>{
 const {data:allowed,error:roleError}=await context.supabase.rpc('has_role',{_user_id:context.userId,_role:'admin'});
 if(roleError||!allowed)return {allowed:false as const,profile:null,products:[],orders:[],items:[]};
 const [p,o,i,profile]=await Promise.all([context.supabase.from('products').select('*').order('created_at',{ascending:false}).limit(1000),context.supabase.from('orders').select('*').order('created_at',{ascending:false}).limit(1000),context.supabase.from('order_items').select('*').limit(1000),context.supabase.from('profiles').select('*').eq('id',context.userId).single()]);
 if(p.error||o.error||i.error)throw new Error('Dashboard could not load');
 return {allowed:true as const,profile:profile.data,products:p.data??[],orders:o.data??[],items:i.data??[]};
});
