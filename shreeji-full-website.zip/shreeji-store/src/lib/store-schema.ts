import { z } from 'zod';
export const productSchema = z.object({ name:z.string().trim().min(1).max(100),note:z.string().trim().max(1000),category:z.string().trim().min(1).max(80),price:z.number().finite().min(0),stock:z.number().int().min(0),image_path:z.string().min(1).max(500),active:z.boolean() });
export const orderSchema = z.object({ name:z.string().trim().min(1).max(100),email:z.union([z.literal(''),z.string().trim().email().max(255)]),phone:z.string().trim().regex(/^[+\d\s()-]{7,20}$/),address:z.string().trim().min(5).max(1000),items:z.array(z.object({id:z.string().uuid(),quantity:z.number().int().min(1).max(99)})).min(1).max(50) }).refine(x=>new Set(x.items.map(i=>i.id)).size===x.items.length, 'Duplicate products');
export type OrderInput = z.infer<typeof orderSchema>;
export function cartTotal(items: {price:number;quantity:number}[]) { return items.reduce((sum,x)=>sum+x.price*x.quantity,0); }
